# IPL Data Analytics dbt Project Explanation

## 1. Introduction

This document provides a comprehensive explanation of the dbt project created for analyzing Indian Premier League (IPL) match data. The project transforms raw IPL data, assumed to be available in a single table, into a structured dimensional model suitable for analytics and visualization. It includes staging models, dimension tables, fact tables, and derived analytics marts.

**Project Goals:**

*   Create clean, well-structured dimension and fact tables.
*   Derive meaningful metrics for player and team performance.
*   Provide a foundation for building insightful dashboards.

## 2. Data Source

*   **Source System:** Assumed to be a database (e.g., Snowflake, MySQL) containing IPL data.
*   **Source Schema:** `cricket_ipl_db` (configurable via `src_cricket_ipl_db.yml`)
*   **Source Table:** `all_ipl_match_data` (configurable via `src_cricket_ipl_db.yml`)
*   **Assumed Granularity:** The source table is assumed to contain data at the delivery level (one row per ball bowled), with match-level information potentially repeated across rows for the same match.

## 3. Dimensional Model (Star Schema)

The project implements a star schema to organize the data for efficient querying and analysis. It consists of several dimension tables providing context and a central fact table containing transactional delivery-level data.

*   **Dimensions:**
    *   `dim_dates`: Provides date attributes (year, month, day, etc.) for time-based analysis.
    *   `dim_events`: Describes the tournament/event details (season, match type, etc.).
    *   `dim_venues`: Contains information about the match venues (stadium name, city).
    *   `dim_teams`: Lists the participating teams.
    *   `dim_players`: Contains a unique list of all players involved (playing XI, batter, bowler, etc.).
    *   `dim_officials`: Lists all match officials (umpires, referees).
    *   `dim_matches`: Provides detailed context for each match, linking other dimensions like event, venue, teams, officials, and date.
*   **Facts:**
    *   `fct_deliveries`: The core fact table, capturing details of each ball delivered (runs, extras, wickets, batter, bowler, etc.). Grain: One row per delivery.
*   **Relationships:** Foreign keys link the `fct_deliveries` table to the relevant dimension tables (e.g., `match_id`, `event_id`, `date_key`, `venue_id`, `batting_team_id`, `bowling_team_id`, `batter_id`, `bowler_id`, etc.). `dim_matches` also links to several other dimensions.

*(Refer to `refined_dimensional_model_design.md` for a detailed schema diagram)*

## 4. dbt Project Structure

The project follows standard dbt conventions:

```
ipl_analytics/
├── analyses/
├── macros/
├── models/
│   ├── staging/
│   │   └── cricket_ipl_db/
│   │       ├── src_cricket_ipl_db.yml  # Source definition
│   │       └── stg_cricket_ipl_db__all_ipl_match_data.sql # Staging model
│   ├── dimensions/
│   │   ├── dim_dates.sql
│   │   ├── dim_events.sql
│   │   ├── dim_matches.sql
│   │   ├── dim_officials.sql
│   │   ├── dim_players.sql
│   │   ├── dim_teams.sql
│   │   └── dim_venues.sql
│   ├── facts/
│   │   └── fct_deliveries.sql
│   ├── intermediate/
│   │   ├── int_player_batting_match_aggregates.sql
│   │   └── int_player_bowling_match_aggregates.sql
│   └── marts/
│       └── analytics/
│           └── mart_player_match_performance.sql
├── seeds/
├── snapshots/
├── tests/
├── dbt_project.yml
└── packages.yml # (if using packages like dbt_utils)
```

*   **staging:** Cleans, renames, and casts types from the source table.
*   **dimensions:** Builds the dimension tables, handling deduplication and key generation.
*   **facts:** Builds the core fact table (`fct_deliveries`).
*   **intermediate:** Creates reusable aggregate models for calculating metrics.
*   **marts:** Builds the final analytics-ready tables combining facts and dimensions.

## 5. Key Model Explanations

*   **`stg_cricket_ipl_db__all_ipl_match_data.sql`**: Selects from the source, renames columns for clarity (e.g., `over_number` -> `over_in_innings`), casts data types (e.g., `dates_1` to `date`), and handles basic cleanup (e.g., `coalesce` for boolean flags).
*   **Dimension Models (`dim_*.sql`)**: 
    *   Typically select distinct attributes from the staging model.
    *   Generate surrogate keys (e.g., `event_id`, `venue_id`, `team_id`) using `dbt_utils.generate_surrogate_key` (MD5 hash) where natural keys are complex or absent.
    *   Use natural keys (`match_id`, `player_id`, `official_id`) where available and appropriate.
    *   Unpivot data where necessary (e.g., `dim_players`, `dim_officials`).
*   **`fct_deliveries.sql`**: 
    *   Joins the staging table with relevant dimension tables to get foreign keys (`event_id`, `match_date_key`, `venue_id`, `batting_team_id`, `bowling_team_id`, `batter_id`, etc.).
    *   Generates a surrogate key (`delivery_key`) for the fact table row.
    *   Selects relevant measures (runs, extras) and flags (is_wicket, is_powerplay).
    *   Configured as incremental to potentially improve performance on subsequent runs.
*   **Intermediate Models (`int_*.sql`)**: 
    *   Aggregate data from `fct_deliveries` at the player-match level (e.g., `int_player_batting_match_aggregates`, `int_player_bowling_match_aggregates`).
    *   Calculate basic aggregates like total runs, balls faced, wickets taken, runs conceded.
*   **`mart_player_match_performance.sql`**: 
    *   Combines batting and bowling aggregates using a full outer join.
    *   Joins with dimension tables (`dim_matches`, `dim_players`, `dim_teams`, `dim_dates`, etc.) to add rich context.
    *   Calculates final performance metrics like strike rates, averages, economy rates.
    *   Provides a wide table suitable for direct use in BI tools.

## 6. Derived Metrics

The project calculates several key performance indicators (KPIs) primarily within the intermediate and mart layers:

*   **Batting:**
    *   Total Runs
    *   Balls Faced
    *   Strike Rate (`(Total Runs / Balls Faced) * 100`)
    *   Batting Average (`Total Runs / Times Out`)
    *   Number of 4s, 6s
    *   Flags for 50s and 100s
*   **Bowling:**
    *   Balls Bowled
    *   Overs Bowled
    *   Runs Conceded
    *   Wickets Taken (excluding run-outs etc.)
    *   Economy Rate (`(Runs Conceded / Overs Bowled)` or `(Runs Conceded * 6) / Balls Bowled`)
    *   Bowling Average (`Runs Conceded / Wickets Taken`)
    *   Bowling Strike Rate (`Balls Bowled / Wickets Taken`)
    *   Dot Balls, Wides, No-Balls

These metrics are available in `mart_player_match_performance.sql`.

## 7. Dashboard Overview

A sample dashboard (`ipl_dashboard.html`) was created using Plotly and sample data derived from the structure of `mart_player_match_performance.sql`. 

*   **Purpose:** To demonstrate the *types* of visualizations possible with the transformed data.
*   **Content:** Includes sample charts for:
    *   Top Run Scorers
    *   Top Wicket Takers
    *   Best Batting Strike Rate (with minimum balls faced)
    *   Best Bowling Economy (with minimum balls bowled)
*   **Using with Real Data:**
    1.  Run the dbt project successfully against your data warehouse (`dbt run`).
    2.  Connect a Business Intelligence (BI) tool (like Tableau, Power BI, Looker, Metabase, etc.) to your data warehouse.
    3.  Connect the BI tool to the `mart_player_match_performance` table (and potentially other dimension/fact tables).
    4.  Recreate or build new visualizations in your BI tool based on the actual data.

## 8. How to Run the Project

1.  **Prerequisites:**
    *   Python 3.9+ installed.
    *   Access to a data warehouse (e.g., Snowflake, BigQuery, Redshift, Postgres).
    *   Raw IPL data loaded into the source table (`all_ipl_match_data`).
2.  **Setup:**
    *   Clone or download the project files.
    *   Navigate to the project root (`ipl_analytics_project`).
    *   Set up a Python virtual environment: `python3 -m venv .venv && source .venv/bin/activate`
    *   Install dependencies: `pip install dbt-core dbt-<your_adapter>` (e.g., `dbt-snowflake`)
    *   Configure your dbt profile (`~/.dbt/profiles.yml` or project-specific) with connection details for your data warehouse. Ensure the database and schema names match those used in `src_cricket_ipl_db.yml` or override using environment variables.
3.  **dbt Commands:**
    *   Test connection: `dbt debug`
    *   Install packages (if using `packages.yml`): `dbt deps`
    *   Run all models: `dbt run`
    *   Run specific models: `dbt run --select staging` or `dbt run --select mart_player_match_performance`
    *   Run tests (if defined): `dbt test`
    *   Generate documentation: `dbt docs generate && dbt docs serve`

## 9. Potential Enhancements / Next Steps

*   **Data Quality Tests:** Add dbt tests (uniqueness, not null, accepted values, relationships) to `schema.yml` files for all models.
*   **Advanced Metrics:** Calculate more complex metrics (e.g., Net Run Rate, Player Impact Scores, partnership stats).
*   **Seed Files:** Use dbt seeds for mapping files (e.g., player name variations, venue corrections) if needed.
*   **Macros:** Develop dbt macros for reusable logic (e.g., calculating overs, safe division).
*   **Performance Tuning:** Optimize models for specific warehouses (clustering, partitioning, incremental strategies).
*   **CI/CD:** Implement Continuous Integration/Continuous Deployment pipelines for automated testing and deployment.
*   **Dashboard Expansion:** Build a more comprehensive interactive dashboard in a dedicated BI tool.
