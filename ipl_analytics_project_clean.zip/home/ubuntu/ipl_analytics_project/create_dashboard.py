import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np

# 1. Define structure and generate sample data based on mart_player_match_performance
# (Simplified structure for dashboard demonstration)
data = {
    'match_id': [1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4],
    'match_date': pd.to_datetime(['2023-04-01', '2023-04-01', '2023-04-01', '2023-04-01', 
                           '2023-04-02', '2023-04-02', '2023-04-02', '2023-04-02',
                           '2023-04-03', '2023-04-03', '2023-04-03', '2023-04-03',
                           '2023-04-04', '2023-04-04', '2023-04-04', '2023-04-04']),
    'player_id': [101, 102, 103, 104, 201, 202, 203, 204, 101, 201, 301, 302, 102, 202, 401, 402],
    'player_name': ['Player A', 'Player B', 'Player C', 'Player D', 'Player E', 'Player F', 'Player G', 'Player H', 
                    'Player A', 'Player E', 'Player I', 'Player J', 'Player B', 'Player F', 'Player K', 'Player L'],
    'team_id': [1, 1, 2, 2, 3, 3, 4, 4, 1, 3, 2, 4, 1, 3, 2, 4],
    'team_name': ['Team X', 'Team X', 'Team Y', 'Team Y', 'Team Z', 'Team Z', 'Team W', 'Team W', 
                  'Team X', 'Team Z', 'Team Y', 'Team W', 'Team X', 'Team Z', 'Team Y', 'Team W'],
    'opponent_team_name': ['Team Y', 'Team Y', 'Team X', 'Team X', 'Team W', 'Team W', 'Team Z', 'Team Z', 
                         'Team Z', 'Team X', 'Team W', 'Team Y', 'Team W', 'Team Y', 'Team Z', 'Team X'],
    'total_runs': [55, 12, 30, 5, 80, 25, 10, 45, 110, 5, 15, 60, 2, 70, 35, 18],
    'balls_faced': [40, 10, 25, 8, 50, 20, 15, 30, 60, 8, 18, 40, 5, 45, 30, 22],
    'batting_strike_rate': [137.5, 120.0, 120.0, 62.5, 160.0, 125.0, 66.7, 150.0, 183.3, 62.5, 83.3, 150.0, 40.0, 155.6, 116.7, 81.8],
    'is_out': [True, False, True, True, True, False, True, True, True, True, False, True, True, True, True, False],
    'balls_bowled': [24, 18, 24, 12, 18, 24, 12, 24, 0, 24, 18, 24, 24, 0, 24, 12],
    'overs_bowled_decimal': [4.0, 3.0, 4.0, 2.0, 3.0, 4.0, 2.0, 4.0, 0.0, 4.0, 3.0, 4.0, 4.0, 0.0, 4.0, 2.0],
    'runs_conceded': [30, 20, 25, 15, 22, 35, 18, 28, 0, 40, 15, 30, 28, 0, 32, 10],
    'wickets_taken': [2, 1, 3, 0, 1, 2, 0, 4, 0, 1, 2, 1, 3, 0, 1, 0],
    'economy_rate': [7.5, 6.67, 6.25, 7.5, 7.33, 8.75, 9.0, 7.0, np.nan, 10.0, 5.0, 7.5, 7.0, np.nan, 8.0, 5.0],
    'winner_team_name': ['Team X', 'Team X', 'Team X', 'Team X', 'Team Z', 'Team Z', 'Team Z', 'Team Z', 
                       'Team X', 'Team X', 'Team X', 'Team X', 'Team Y', 'Team Y', 'Team Y', 'Team Y']
}
df = pd.DataFrame(data)
df['is_winning_team_player'] = df['team_name'] == df['winner_team_name']

# Aggregate stats per player across sample matches
player_agg = df.groupby(['player_id', 'player_name']).agg(
    total_matches = pd.NamedAgg(column='match_id', aggfunc='nunique'),
    total_runs = pd.NamedAgg(column='total_runs', aggfunc='sum'),
    total_balls_faced = pd.NamedAgg(column='balls_faced', aggfunc='sum'),
    total_times_out = pd.NamedAgg(column='is_out', aggfunc='sum'),
    total_balls_bowled = pd.NamedAgg(column='balls_bowled', aggfunc='sum'),
    total_runs_conceded = pd.NamedAgg(column='runs_conceded', aggfunc='sum'),
    total_wickets_taken = pd.NamedAgg(column='wickets_taken', aggfunc='sum')
).reset_index()

# Calculate overall metrics
player_agg['batting_average'] = player_agg.apply(lambda x: round(x['total_runs'] / x['total_times_out'], 2) if x['total_times_out'] > 0 else np.nan, axis=1)
player_agg['batting_strike_rate'] = player_agg.apply(lambda x: round((x['total_runs'] * 100.0) / x['total_balls_faced'], 2) if x['total_balls_faced'] > 0 else 0, axis=1)
player_agg['bowling_average'] = player_agg.apply(lambda x: round(x['total_runs_conceded'] / x['total_wickets_taken'], 2) if x['total_wickets_taken'] > 0 else np.nan, axis=1)
player_agg['bowling_economy_rate'] = player_agg.apply(lambda x: round((x['total_runs_conceded'] * 6.0) / x['total_balls_bowled'], 2) if x['total_balls_bowled'] > 0 else np.nan, axis=1)

# 2. Create Plotly Visualizations
fig = make_subplots(
    rows=2, cols=2,
    subplot_titles=("Top Run Scorers", "Top Wicket Takers", 
                    "Best Batting Strike Rate (Min 50 Balls)", "Best Bowling Economy (Min 30 Balls)"),
    vertical_spacing=0.15
)

# Top Run Scorers
top_runs = player_agg.nlargest(10, 'total_runs')
fig.add_trace(go.Bar(x=top_runs['player_name'], y=top_runs['total_runs'], name='Total Runs'), row=1, col=1)

# Top Wicket Takers
top_wickets = player_agg.nlargest(10, 'total_wickets_taken')
fig.add_trace(go.Bar(x=top_wickets['player_name'], y=top_wickets['total_wickets_taken'], name='Total Wickets'), row=1, col=2)

# Best Batting Strike Rate (with minimum balls faced)
min_balls_batting = 50
best_sr = player_agg[player_agg['total_balls_faced'] >= min_balls_batting].nsmallest(10, 'batting_strike_rate')
fig.add_trace(go.Bar(x=best_sr['player_name'], y=best_sr['batting_strike_rate'], name='Strike Rate'), row=2, col=1)

# Best Bowling Economy (with minimum balls bowled)
min_balls_bowling = 30
best_econ = player_agg[player_agg['total_balls_bowled'] >= min_balls_bowling].nsmallest(10, 'bowling_economy_rate')
fig.add_trace(go.Bar(x=best_econ['player_name'], y=best_econ['bowling_economy_rate'], name='Economy Rate'), row=2, col=2)

# Update layout
fig.update_layout(
    title_text='IPL Player Performance Dashboard (Sample Data)',
    height=800,
    showlegend=False
)
fig.update_xaxes(tickangle=45)

# 3. Save dashboard to HTML
output_file = '/home/ubuntu/ipl_analytics_project/ipl_dashboard.html'
fig.write_html(output_file, auto_open=False)

print(f"Dashboard saved to {output_file}")

